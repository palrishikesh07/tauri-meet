Write-Host "========================================="
Write-Host " Meet Capture - Windows Build"
Write-Host "========================================="

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "Checking dependencies..."

node --version
npm --version
go version
rustc --version
cargo --version
ffmpeg -version

Write-Host ""
Write-Host "Installing npm dependencies..."

npm install

Write-Host ""
Write-Host "Building Windows Go engine..."

npm run engine:windows

if (-not (Test-Path "engine\meetrec.exe")) {
    throw "engine\meetrec.exe was not created"
}

Write-Host ""
Write-Host "Building frontend..."

npm run build

Write-Host ""
Write-Host "Building Tauri Windows application..."

npm run tauri build `
    -- `
    --target x86_64-pc-windows-msvc `
    --config src-tauri/tauri.windows.conf.json

Write-Host ""
Write-Host "Build completed."
Write-Host ""

$bundlePath = "src-tauri\target\x86_64-pc-windows-msvc\release\bundle"

Write-Host "Generated bundles:"

if (Test-Path "$bundlePath\msi") {
    Get-ChildItem "$bundlePath\msi"
}

if (Test-Path "$bundlePath\nsis") {
    Get-ChildItem "$bundlePath\nsis"
}