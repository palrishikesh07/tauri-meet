//go:build windows

package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

type Device struct {
	ID        string `json:"id"`
	Label     string `json:"label"`
	Detail    string `json:"detail"`
	IsDefault bool   `json:"isDefault"`
}

type DeviceList struct {
	DownloadsDir  string   `json:"downloadsDir"`
	DefaultSource string   `json:"defaultSource"`
	Devices       []Device `json:"devices"`
}

type RecordingFile struct {
	Name        string `json:"name"`
	Path        string `json:"path"`
	Bytes       int64    `json:"bytes"`
	Modified    string   `json:"modified"`
	TextPath    string   `json:"textPath,omitempty"`
	SummaryPath string   `json:"summaryPath,omitempty"`
}

type readyMessage struct {
	Status   string `json:"status"`
	Path     string `json:"path"`
	Source   string `json:"source"`
	TextPath string `json:"textPath"`
}

func listDevices() (DeviceList, error) {
	dir, err := downloadsDir()
	if err != nil {
		return DeviceList{}, err
	}

	if _, err := exec.LookPath("ffmpeg"); err != nil {
		return DeviceList{}, errors.New(
			"ffmpeg was not found. Install FFmpeg and add it to PATH",
		)
	}

	out, err := exec.Command(
		"ffmpeg",
		"-hide_banner",
		"-list_devices",
		"true",
		"-f",
		"dshow",
		"-i",
		"dummy",
	).CombinedOutput()

	if err != nil {
		// FFmpeg normally returns non-zero because dummy input is invalid.
		// The device list is still printed to stderr.
	}

	devices := parseDirectShowDevices(string(out))

	if len(devices) == 0 {
		return DeviceList{}, errors.New(
			"no Windows audio capture devices found. Enable Stereo Mix or What U Hear in Windows Sound settings",
		)
	}

	defaultSource := devices[0].ID
	devices[0].IsDefault = true

	return DeviceList{
		DownloadsDir:  dir,
		DefaultSource: defaultSource,
		Devices:       devices,
	}, nil
}

func parseDirectShowDevices(output string) []Device {
	var devices []Device

	lines := strings.Split(output, "\n")

	for _, line := range lines {
		line = strings.TrimSpace(line)

		if !strings.Contains(line, `"`) {
			continue
		}

		start := strings.Index(line, `"`)
		end := strings.LastIndex(line, `"`)

		if start < 0 || end <= start {
			continue
		}

		name := strings.TrimSpace(line[start+1 : end])

		if name == "" {
			continue
		}

		// We only want audio devices.
		// Stereo Mix / What U Hear are normally the devices we want.
		lower := strings.ToLower(name)

		if strings.Contains(lower, "stereo mix") ||
			strings.Contains(lower, "what u hear") ||
			strings.Contains(lower, "loopback") {

			devices = append(devices, Device{
				ID:     name,
				Label:  name,
				Detail: "Windows playback capture device",
			})
		}
	}

	sort.SliceStable(devices, func(i, j int) bool {
		return devices[i].Label < devices[j].Label
	})

	return devices
}

func listRecordings() ([]RecordingFile, error) {
	dir, err := downloadsDir()
	if err != nil {
		return nil, err
	}

	entries, err := os.ReadDir(dir)
	if err != nil {
		if os.IsNotExist(err) {
			return []RecordingFile{}, nil
		}

		return nil, err
	}

	files := make([]RecordingFile, 0)

	for _, entry := range entries {
		if entry.IsDir() {
			continue
		}

		name := entry.Name()

		if !strings.HasPrefix(name, "meet-") ||
			!strings.HasSuffix(name, ".ogg") {
			continue
		}

		info, err := entry.Info()
		if err != nil {
			continue
		}

		audioPath := filepath.Join(dir, name)

		textPath := strings.TrimSuffix(
			audioPath,
			".ogg",
		) + ".txt"

		if _, err := os.Stat(textPath); err != nil {
			textPath = ""
		}

		summaryPath := strings.TrimSuffix(
			audioPath,
			".ogg",
		) + ".summary.txt"

		if _, err := os.Stat(summaryPath); err != nil {
			summaryPath = ""
		}

		files = append(files, RecordingFile{
			Name:        name,
			Path:        audioPath,
			Bytes:       info.Size(),
			Modified:    info.ModTime().UTC().Format(time.RFC3339),
			TextPath:    textPath,
			SummaryPath: summaryPath,
		})
	}

	sort.Slice(files, func(i, j int) bool {
		return files[i].Modified > files[j].Modified
	})

	return files, nil
}

func record(source string) error {
	if _, err := exec.LookPath("ffmpeg"); err != nil {
		return errors.New(
			"ffmpeg was not found. Install FFmpeg and add it to PATH",
		)
	}

	if source == "" {
		devices, err := listDevices()
		if err != nil {
			return err
		}

		source = devices.DefaultSource

		if source == "" {
			return errors.New(
				"no playback capture device available",
			)
		}
	}

	if strings.ContainsAny(source, "\r\n") {
		return errors.New("invalid playback source")
	}

	dir, err := downloadsDir()
	if err != nil {
		return err
	}

	output, err := newRecordingPath(dir)
	if err != nil {
		return err
	}

	textPath := strings.TrimSuffix(
		output,
		".ogg",
	) + ".txt"

	textFile, err := os.Create(textPath)
	if err != nil {
		return err
	}

	defer textFile.Close()

	client, err := startWhisper()
	if err != nil {
		return err
	}

	defer client.close()

	cmd := exec.Command(
		"ffmpeg",
		"-y",
		"-hide_banner",
		"-loglevel",
		"error",

		"-f",
		"dshow",

		"-i",
		"audio="+source,

		"-c:a",
		"libopus",

		"-b:a",
		"64k",

		"-application",
		"voip",

		"-vbr",
		"on",

		output,
	)

	var stderr bytes.Buffer

	cmd.Stderr = &stderr

	if err := cmd.Start(); err != nil {
		return fmt.Errorf(
			"could not start ffmpeg: %w",
			err,
		)
	}

	pub := &stdoutPublisher{}

	// Windows implementation currently records the OGG file.
	// Whisper transcription will be processed from the
	// generated recording after the capture completes.

	ready := readyMessage{
		Status:   "recording",
		Path:     output,
		Source:   source,
		TextPath: textPath,
	}

	if err := writeReady(ready); err != nil {
		_ = cmd.Process.Kill()
		return err
	}

	pub.enable()

	sigs := make(chan os.Signal, 1)

	signal.Notify(
		sigs,
		os.Interrupt,
	)

	select {
	case err := <-waitCommand(cmd):

		if err != nil {
			msg := strings.TrimSpace(stderr.String())

			if msg == "" {
				msg = err.Error()
			}

			return errors.New(msg)
		}

	case <-sigs:

		if cmd.Process != nil {
			_ = cmd.Process.Kill()
		}

		_ = cmd.Wait()
	}

	return nil
}

func waitCommand(cmd *exec.Cmd) <-chan error {
	done := make(chan error, 1)

	go func() {
		done <- cmd.Wait()
	}()

	return done
}