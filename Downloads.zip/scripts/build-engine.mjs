import { execSync } from "node:child_process";

console.log("Building Windows recording engine...");

execSync(
  "go -C engine build -o meetrec.exe .",
  {
    stdio: "inherit",
    shell: true
  }
);

console.log("Windows recording engine built successfully.");